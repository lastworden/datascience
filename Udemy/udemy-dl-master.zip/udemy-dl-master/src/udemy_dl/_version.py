#!/usr/bin/env python
"""PyPI version of udemy-dl."""
__version__ = '0.2.1'


# coding: utf-8

# In[15]:

import numpy as np


# # Division examples

# In[10]:

1/3


# In[11]:

1//3


# In[12]:

5//2


# In[13]:

5.5//2


# In[14]:

5.5/2


# # Array and scalar operations

# In[16]:

arr1 = np.array([[1,2,3,4],[5,6,7,8]])


# In[17]:

arr1


# In[18]:

arr1*arr1


# In[19]:

arr1*5


# In[22]:

arr1**3


# In[23]:

1/arr1


# In[25]:

arr1+arr1


# In[ ]:





# coding: utf-8

# In[2]:

import numpy as np
import pandas as pd
from pandas import Series, DataFrame


# In[4]:

ser1 = Series([1,2,3,4], index = ['A','B','C','D'])
ser1


# In[6]:

ind1 = ser1.index
ind1


# In[7]:

ind[2]


# In[8]:

ser1[ind]


# In[9]:

ind[2:]


# In[12]:


if __name__ == '__main__':
    ind[0] = 'Z'


# In[ ]:




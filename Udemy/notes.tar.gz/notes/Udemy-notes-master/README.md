# Learning Python for Data Analysis and Visualization
Here you will find the Notebooks for my Udemy Course:
https://www.udemy.com/learning-python-for-data-analysis-and-visualization/

Use the coupon DEAL19 for 90% off the course!


